# Roteira

SaaS para gerar roteiros de vídeos curtos com IA. O projeto possui frontend React e backend FastAPI/MongoDB.

## Arquitetura de produção

- **Frontend:** Netlify
- **Backend:** serviço Python (o `render.yaml` deste repositório já deixa o deploy preparado)
- **Banco:** MongoDB hospedado, como MongoDB Atlas
- **Login:** Emergent Google OAuth
- **Pagamento:** PIX manual com aprovação pelo painel admin

> O Netlify hospeda o frontend. O `backend/server.py` precisa de um serviço Python separado; apenas enviar o repositório ao Netlify não executa o FastAPI.

## 1. Segurança antes do deploy

Credenciais que já foram compartilhadas ou commitadas devem ser consideradas expostas. Gere/troque a chave de IA, a senha de administrador e o `JWT_SECRET`. Nunca envie arquivos `.env` ao GitHub. Este projeto inclui apenas `.env.example`.

## 2. Banco de dados

Crie um banco MongoDB hospedado e copie a URI `mongodb+srv://...`. No backend configure:

```env
MONGO_URL=mongodb+srv://...
DB_NAME=roteira
```

`mongodb://localhost:27017` serve apenas quando o MongoDB está rodando na mesma máquina durante desenvolvimento local.

## 3. Backend

Use o `render.yaml` para criar o serviço Python ou configure manualmente:

```bash
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port $PORT
```

Defina todas as variáveis descritas em `backend/.env.example`. Em produção:

```env
CORS_ORIGINS=https://SEU-SITE.netlify.app
APP_PUBLIC_URL=https://SEU-SITE.netlify.app
```

Teste o backend abrindo:

```text
https://SEU-BACKEND/api/health
```

O esperado é `{"status":"ok","database":"ok"}`.

## 4. Frontend no Netlify

O `netlify.toml` na raiz já configura build e fallback do React Router. No Netlify adicione a variável:

```env
REACT_APP_BACKEND_URL=https://SEU-BACKEND
```

Depois faça um novo deploy. Não use URL `*.preview.emergentagent.com`; URLs de preview são temporárias.

## 5. Login Google

O callback agora aceita `session_id` tanto no hash (`#session_id=...`) quanto na query (`?session_id=...`) e existe uma rota explícita `/auth/callback`.

Fluxo esperado:

1. `/login` → Continuar com Google
2. Google/Emergent retorna para `https://SEU-SITE/auth/callback`
3. frontend envia o `session_id` para `/api/auth/session`
4. backend salva usuário/sessão no MongoDB
5. token é salvo localmente e `/api/auth/me` mantém o usuário logado

## 6. PIX manual

Configure somente no backend:

```env
PIX_KEY=SUA_CHAVE_PIX
PIX_KEY_TYPE=Celular
PIX_HOLDER_NAME=SEU_NOME
PIX_HOLDER_CITY=RECIFE
PREMIUM_PRICE_BRL=5
PREMIUM_DAYS=30
```

O usuário envia o ID da transação. A solicitação aparece no painel admin para aprovação manual.

## Desenvolvimento local

Backend:

```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

Frontend:

```bash
cd frontend
cp .env.example .env
# troque REACT_APP_BACKEND_URL para http://localhost:8001
yarn install
yarn start
```
