# Checklist rápido de publicação

## 1) Troque as credenciais expostas
- Gere uma nova `EMERGENT_LLM_KEY`.
- Crie uma nova `ADMIN_PASSWORD`.
- Gere um novo `JWT_SECRET` com pelo menos 32 caracteres.
- Nunca coloque esses valores no GitHub.

## 2) MongoDB
Crie um MongoDB hospedado e copie a URI `mongodb+srv://...`.

No backend configure:
- `MONGO_URL`
- `DB_NAME=roteira`

## 3) Backend
Publique o FastAPI usando o `render.yaml` ou outro host Python.

Configure também:
- `CORS_ORIGINS=https://SEU-SITE.netlify.app`
- `APP_PUBLIC_URL=https://SEU-SITE.netlify.app`
- `EMERGENT_LLM_KEY`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `JWT_SECRET`
- variáveis PIX

Teste: `https://SEU-BACKEND/api/health`

## 4) Netlify
Conecte este repositório. O `netlify.toml` da raiz já define o build.

Em Environment Variables do Netlify:
- `REACT_APP_BACKEND_URL=https://SEU-BACKEND`

Faça novo deploy.

## 5) Teste final
1. Abra `/login`.
2. Clique em Continuar com Google.
3. Volte autenticado ao `/dashboard`.
4. Atualize a página e confirme que continua logado.
5. Gere um roteiro.
6. Teste o PIX e a aprovação no admin.

## Render: pacote do Emergent
O backend usa `emergentintegrations==0.2.0`. O `requirements.txt` já inclui o índice privado oficial necessário para o Render instalar esse pacote. O arquivo `backend/.python-version` fixa Python 3.11.9 para evitar incompatibilidades com Python 3.14.
